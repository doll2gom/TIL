a, b, c = map(int,input().split())
A = '0' + str(a)
print(f'{A}-{b}-{c}')