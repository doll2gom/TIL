a = int(input())
n = 0
if a < 0:
    print("-1")
elif a > 0:
    n += a
    print(n)