T = int(input())
i = 0
for t in range(0,T):
    a = int(input())
    i += a
if i > T/2:
    print("Junhee is cute!")
else:
    print("Junhee is not cute!")